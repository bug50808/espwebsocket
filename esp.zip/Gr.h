#include <Arduino.h>
#include <DNSServer.h>

#ifdef ESP32
#include <WiFi.h>
#include <AsyncTCP.h>
#include <SPIFFS.h>
#elif defined(ESP8266)
#include <ESP8266WiFi.h>
#include <ESPAsyncTCP.h>
#include <LittleFS.h>
#endif
#include <ESPAsyncWebServer.h>
#include <AsyncElegantOTA.h>
#include <Arduino_JSON.h>

const char* ssid = "Xiaomi_0485";
const char* password = "qwertyuiop123.";

AsyncWebServer server(80);
AsyncWebSocket ws("/ws");
AsyncEventSource events("/events");


void initWiFi() {
  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid, password);
  Serial.print("正在连接WiFi ..");
  while (WiFi.status() != WL_CONNECTED) {
    Serial.print('.');
    delay(1000);
  }
  Serial.println("");
  Serial.print("IP:");
  Serial.println(WiFi.localIP());
}

void littlefs() {
  if (!LittleFS.begin()) {
    Serial.println("LittleFS库初始化失败！");
  }
  Serial.println("LittleFS库初始化成功！");
}

void spifs() {
  if (!SPIFFS.begin()) {
    Serial.println("SPIFFS库初始化失败！");
  }
  Serial.println("SPIFFS库初始化成功！");
}


//----------------------------------------------------------------------------------------------
void BeginSetup(){
  Serial.begin(115200);
  initWiFi();

  #ifdef ESP32
  spifs();
  #elif defined(ESP8266)
  littlefs();
  #endif

}




