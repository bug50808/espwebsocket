var gateway = `ws://${window.location.hostname}/ws`;
var websocket;
var page;
window.addEventListener('load', onLoad);
function onLoad(event) {
    initWebSocket();
}


function load(event) {
    page = event;

    
    console.log("触发页面");
    console.log(event);


}

function initWebSocket() {
    console.log('尝试 WebSocket 连接...');
    websocket = new WebSocket(gateway);
    websocket.onopen = onOpen;//连接成功
    websocket.onclose = onClose;//连接断开处理
    websocket.onmessage = onMessage;//收到消息处理

}

function onOpen(event) {
    console.log('WebSocket 连接已打开');
    console.log("发送页面属性");
    var obj = {
        load: page
    }
    console.log(json);
    var json = JSON.stringify(obj);
    websocket.send(json);
}
function onClose(event) {
    console.log('WebSocket 连接已关闭');
    setTimeout(initWebSocket, 1000);
}

//消息处理
function onMessage(event) {
    var obj = JSON.parse(event.data);

    console.log("收到数据");
    console.log(obj);
    if (obj.instructions = "1") {
        homepage(event);
    }

}

function updateDateTime() {
    var currentdate = new Date();
    var datetime = currentdate.getDate() + "/"
        + (currentdate.getMonth() + 1) + "/"
        + currentdate.getFullYear() + " at "
        + currentdate.getHours() + ":"
        + currentdate.getMinutes() + ":"
        + currentdate.getSeconds();
    document.getElementById("update-time").innerHTML = datetime;
    console.log(datetime);
}

//更新主页显示解析
function homepage(event) {
    var obj = JSON.parse(event.data);
    document.getElementById("version").innerHTML = obj.version;
    document.getElementById("ChipId").innerHTML = obj.ChipId;
    document.getElementById("CpuFreqMHz").innerHTML = obj.CpuFreqMHz;
    document.getElementById("SSID").innerHTML = obj.SSID;
    document.getElementById("IP").innerHTML = obj.IP;
    document.getElementById("gateway").innerHTML = obj.gateway;
    document.getElementById("DNS").innerHTML = obj.DNS;
    document.getElementById("APMAC").innerHTML = obj.APMAC;
    document.getElementById("STAMAC").innerHTML = obj.STAMAC;
    document.getElementById("Uptime").innerHTML = obj.Uptime;
    document.getElementById("SketchSize").innerHTML = obj.SketchSize;
    document.getElementById("SketchSpace").innerHTML = obj.SketchSpace;
    document.getElementById("usedBytes").innerHTML = obj.usedBytes;
    document.getElementById("available").innerHTML = obj.available;
    document.getElementById("totalBytes").innerHTML = obj.totalBytes;
    updateDateTime();

}
//===================================================================================

function handleSTA() {
    document.getElementById("hideBSSID").style.display = "block",
    document.getElementById("scanb").style.display = "block",
    document.getElementById('wifibssid').value ="",
    document.getElementById("inputtohide").value ="",
    document.getElementById('wifipass').value =""



}

function handleAP() {
    document.getElementById("hideBSSID").style.display = "none",
    document.getElementById("scanb").style.display = "none",
    document.getElementById("inputtohide").style.display = "block",
    document.getElementById("inputtohide").value ="",
    document.getElementById("ssid").style.display = "none"

        
}
function listBSSID() {
    var e = document.getElementById("ssid");
    document.getElementById("wifibssid").value = e.options[e.selectedIndex].bssidvalue
}

function scanWifi() {
    websock.send('{"command":"scan"}'),
        document.getElementById("scanb").innerHTML = "...",
        document.getElementById("inputtohide").style.display = "none";
    var e = document.getElementById("ssid");
    for (e.style.display = "inline"; e.hasChildNodes();) e.removeChild(e.lastChild)
}
function savenetwork() {
    
    radiobtn1 = document.getElementById("wmodeap").checked;//单选框状态
    console.log(radiobtn1);

    if (document.getElementById("wmodeap").checked) {
        var password = document.getElementById("wifipass").value;
        if(password.length > 1 && password.length < 8 ){
            alert("输入的密码必须大于八位");
            document.getElementById('wifipass').value =""
            return;
        }else{
           
            if(password.length == 0){
                alert("SSID是："+(document.getElementById("inputtohide").value))
            }else{
                alert("SSID是："+(document.getElementById("inputtohide").value) + " 密码是："+(document.getElementById("wifipass").value))
            }
            
            //发送请求保存

        } 
        return; 
    }



        // if (config.network.bssid = "", !checkOctects("ipaddress")) return;
    //     if (!checkOctects("subnet")) return;
    //     config.network.apip = document.getElementById("ipaddress").value,
    //         config.network.apsubnet = document.getElementById("subnet").value,
    //         1 === parseInt(document.querySelector('input[name="hideapenable"]:checked').value) ? config.network.hide = 1 : config.network.hide = 0
    //} else if (config.network.bssid = document.getElementById("wifibssid").value, 1 === parseInt(document.querySelector('input[name="dhcpenabled"]:checked').value)) config.network.dhcp = 1;
    // else {
    //     if (config.network.dhcp = 0, !checkOctects("ipaddress")) return;
    //     if (!checkOctects("subnet")) return;
    //     if (!checkOctects("dnsadd")) return;
    //     if (!checkOctects("gateway")) return;
    //     config.network.ip = document.getElementById("ipaddress").value,
    //         config.network.dns = document.getElementById("dnsadd").value,
    //         config.network.subnet = document.getElementById("subnet").value,
    //         config.network.gateway = document.getElementById("gateway").value
    // }
    // config.network.wmode = e,
    //     config.network.pswd = document.getElementById("wifipass").value,
    //     config.network.offtime = parseInt(document.getElementById("disable_wifi_after_seconds").value),
    //     uncommited()
}

function savenetwork1() {}


function checkOctects(e) {
    var t = document.getElementById(e);
    return !! t.value.match(/^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/) || (alert("您在上输入的地址无效 " + e), t.focus(), !1)
}